#define SPH_SVN_TAG "release"
#define SPH_SVN_REV 4245
#define SPH_SVN_REVSTR "4245"
#define SPH_SVN_TAGREV "r4245"
#define SPHINX_TAG "-release"
